export const makeUrl = (relativePath) => {
  const extra = "https://res.cloudinary.com/gstorm/image/upload/v1637481425/audiophile/"
  return extra + relativePath;
}